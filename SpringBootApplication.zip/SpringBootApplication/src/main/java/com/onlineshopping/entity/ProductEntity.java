package com.onlineshopping.entity;

public class ProductEntity {

}
