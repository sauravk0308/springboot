package com.onlineshopping.model;

public class ProductModel {

}
