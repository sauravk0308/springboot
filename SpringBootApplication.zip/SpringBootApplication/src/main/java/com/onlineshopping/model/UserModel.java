package com.onlineshopping.model;

public class UserModel {

}
