package com.onlineshopping.services;

import com.onlineshopping.model.UserModel;

public interface UserServices {
	public void saveOrUpdate(UserModel user);
	public void delete(UserModel user);
}
