package com.onlineshopping;


//import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.Configuration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@EnableSwagger2
@Configuration
@SpringBootApplication1
public class SpringBootApplication1 {
 
	public static void main(String[] args) {
		//SpringApplication.run(SpringBootApplication.class, args);
	}
 
}