package ch.appuio.techlab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springboots2idemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springboots2idemoApplication.class, args);
	}
}
