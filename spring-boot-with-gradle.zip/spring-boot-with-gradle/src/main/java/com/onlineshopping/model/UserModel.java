package com.onlineshopping.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter

public class UserModel {
	private int id;
	private String username;
	private String email;
	private String password;
	
	
	
}
