package com.onlineshopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.onlineshopping.model.UserModel;

@SpringBootApplication
public class SpringbootsDemoApplication {

	public static void main(String[] args) {
		
		SpringApplication.run(SpringbootsDemoApplication.class, args);
	}
}
