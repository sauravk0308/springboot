package com.onlineshopping.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.onlineshopping.model.Hello;

public interface HelloRepository extends JpaRepository<Hello, Long>{
	
	List<Hello> findAllByOrderByIdDesc();

}
