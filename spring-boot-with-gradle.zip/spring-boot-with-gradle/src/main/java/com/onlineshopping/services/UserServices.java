package com.onlineshopping.services;

public interface UserServices {

}
